FFmpeg README
=============

1) Documentation
----------------

* Read the documentation in the doc/ directory in git.

  You can also view it online at http://ffmpeg.org/documentation.html

2) Licensing
------------

* See the LICENSE file.

3) Build and Install
--------------------

* See the INSTALL file.
